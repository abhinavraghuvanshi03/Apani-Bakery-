# Apni Bakery Flutter App
Starter Android/iOS app for Apni Bakery.
WhatsApp: +91 89485 95402
Build with Flutter: `flutter pub get` then `flutter build apk --release`.
